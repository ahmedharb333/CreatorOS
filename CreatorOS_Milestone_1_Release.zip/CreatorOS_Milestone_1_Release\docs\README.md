# CreatorOS — Documentation Index (Milestone 1 Release)

This folder is the documentation set for the **Milestone 1 Release Package**. Start here.

| Document | Purpose |
|---|---|
| [MILESTONE_1_REPORT.md](MILESTONE_1_REPORT.md) | The milestone report — objectives, features, architecture, files, remaining work, limitations, risks, M2 recommendations. **Read first.** |
| [REQUIREMENT_COVERAGE.md](REQUIREMENT_COVERAGE.md) | Every requirement mapped to implementation + status. |
| [TEST_RESULTS.md](TEST_RESULTS.md) | Totals, passed/failed/skipped, evidence, edge cases. |
| [KNOWN_ISSUES.md](KNOWN_ISSUES.md) | Issues classified Critical / High / Medium / Low. |
| [INSTALLATION.md](INSTALLATION.md) | Install via clasp + verify + capture test output. |
| [CODE_REVIEW_GUIDE.md](CODE_REVIEW_GUIDE.md) | Reviewer orientation — read order, invariants, checklist. |
| [ARCHITECTURE_DECISION_RECORDS.md](ARCHITECTURE_DECISION_RECORDS.md) | ADR-001…013 — the key architectural decisions and their trade-offs. |
| [CONCEPTS_GOAL_VS_OBJECTIVE.md](CONCEPTS_GOAL_VS_OBJECTIVE.md) | Strategic Goal vs Content Objective — definitions, vocabularies, mapping. |
| [ASSUMPTIONS.md](ASSUMPTIONS.md) | Resolved conflicts (C1–C3), filled gaps (G1–G3), decisions (D1–D3, E1–E2). |
| [DEVIATIONS.md](DEVIATIONS.md) | Documented deviations from the spec letter (D-01…D-03). |
| [CHANGELOG.md](CHANGELOG.md) | Version history (incl. post-approval corrections). |

Related registers live at the package root: `README.md` (project overview), `RECOMMENDATIONS.md`
(ranked improvement proposals awaiting approval). Source is under `src/`, tests under `tests/` (Node harness
in `tests/node/`), sample data under `sample-data/`, and release artifacts/manifest under `release/`.

**Status:** Milestone 1 **approved** by Product QA with required corrections applied (tests executed 58/58,
multi-dependency, goal/objective clarified, folder READMEs, ADRs). Proceeding to Milestone 2.
