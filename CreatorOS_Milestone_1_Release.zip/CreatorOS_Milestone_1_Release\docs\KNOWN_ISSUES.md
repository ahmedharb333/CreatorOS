# CreatorOS — Known Issues & Limitations (Milestone 1)

Issues classified by severity: **Critical** (blocks release / data loss) · **High** (major function broken
or unsafe) · **Medium** (limitation with a workaround) · **Low** (cosmetic / documentation / deferred detail).

## Critical

_None._

## High

_None._

## Medium

_None._ (The single-dependency limitation below only affects future task-generation and has a clear
upgrade path; it is not currently exercised by any shipped feature, so it is classified Low.)

## Low

| ID | Area | Description | Plan |
|---|---|---|---|
| I-01 | Testing | Spreadsheet-bound suites (Schema/Id-counter/Repository) are authored but not yet executed in Apps Script — the build environment has no bound project or Spreadsheet API. Pure-logic (34/34) and static analysis (25/25) are executed. | Product Owner runs `clasp push` → Initialize/Repair → **Run Tests**; paste output into `TEST_RESULTS.md §5`. |
| I-02 | Schema | `CONTENT.Objective` value list is provisional — undocumented in the specs (ASSUMPTIONS G2). Current default: Awareness, Engagement, Education, Conversion, Retention, Monetization. | Confirm/refine with Product Owner; it is CONFIG-driven, so no code change needed. |
| I-03 | Deploy | `.clasp.json` `scriptId` is a placeholder until a bound Apps Script project exists. | Create a Google Sheet → Apps Script → copy Script ID into `.clasp.json` (or `clasp create`). |
| I-04 | Docs | Spec files `04_Master_PRD` and `16_Workbook_Schema` still show the 5-value Strategic Goal list; code/validations use the approved 7-value standard (ASSUMPTIONS C2). | Doc-maintenance pass to reconcile the two files to 7 values. |
| I-05 | Schema | Workflow `Dependency_Sequence` is single-valued; one default step (YouTube long-form Final QA) has two logical predecessors (ASSUMPTIONS G3). Not yet exercised (task scheduling is M2). | If M2 scheduling needs both edges, add a delimited multi-dependency field (MINOR schema bump). |

**Summary:** 0 Critical, 0 High, 0 Medium, 5 Low. No issue blocks Product QA of Milestone 1.
