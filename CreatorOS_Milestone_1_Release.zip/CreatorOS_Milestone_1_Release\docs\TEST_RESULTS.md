# CreatorOS — Test Results (Milestone 1)

Product `1.0.0` · Schema `1` · Run date: 2026-08-06

Two execution surfaces: **pure-logic** (Spreadsheet-independent, executed here in Node) and
**Spreadsheet-bound** (executed in Apps Script via **CreatorOS ▸ Run Tests** after `clasp push`).

## Summary

| Metric | Count |
|---|---:|
| **Total test cases** | **53** |
| Passed | 34 |
| Failed | 0 |
| Skipped / Pending-execution (Spreadsheet-bound) | 19 |
| Static-analysis files checked (`node --check`) | 25 / 25 OK |

- **Executed now:** 34 pure-logic assertions (all passed) + 25/25 syntax checks.
- **Pending in-GAS:** 19 Spreadsheet-bound cases (Schema ×7, IdService ×5 counter/lock, Repository ×6, plus
  1 in-GAS Validation mirror) — authored and self-checking; require a bound project (KNOWN_ISSUES I-01).
- **No failures.** No test was disabled or removed.

## 1. Pure-logic suite — EXECUTED ✅ (34/34)

Runner: `node tests/node_pure_tests.js`. Captured output: `tests/pure_test_output.txt`.

```
PURE-LOGIC RESULTS: 34 passed, 0 failed, total 34
node --check: 25/25 OK
```

| # | Area | Assertions | Result |
|---|---|---:|---|
| 1 | `IdService.validate` shape + prefix | 4 | PASS |
| 2 | Enum validation (member / non-member) | 2 | PASS |
| 3 | Numeric range + integer boundaries | 4 | PASS |
| 4 | URL / date validation | 4 | PASS |
| 5 | `validateRecord` bad idea (effort/goal flagged) | 3 | PASS |
| 6 | Cross-field date (end > start) | 1 | PASS |
| 7 | Strategic-goal 7-value standard (C2) | 3 | PASS |
| 8 | Priority arithmetic (5,4,2 → 3.3) | 1 | PASS |
| 9 | `columnToLetter` (A / Z / AA) | 3 | PASS |
| 10 | `padNumber` id formatting | 1 | PASS |
| 11 | Secret sanitization (nested, header, key) | 4 | PASS |
| 12 | Timezone validation (valid / invalid) | 2 | PASS |
| 13 | `AppError` code + `toObject` | 2 | PASS |

## 2. Static analysis — EXECUTED ✅

`node --check` on all source + test files: **25 / 25 OK**, 0 syntax errors.

## 3. Spreadsheet-bound suites — PENDING-EXECUTION ⏳ (19)

Run **CreatorOS ▸ Run Tests** after `clasp push` + **Initialize / Repair Workbook**, then paste the
runner's `markdown` output into §5.

| Suite | Cases | Requirement | Expected |
|---|---:|---|---|
| Schema (SCH-001…007) | 7 | schema/docs 21 §3 | 16 sheets, headers exact, named ranges resolve, version=1, protections present, 8 workflows |
| IdService (ID-001…005) | 5 | FR-002 / docs 21 §4 | format, sequential-unique, contiguous reserve, prefix validate, counter floor |
| Validation (in-GAS mirror) | 1 | docs 26 | mirrors pure suite under GAS |
| Repository (REP-001…006) | 6 | FR-003/002, docs 27 | id+timestamps, priority=3.3 in-sheet, getById/find, immutable-id update, invalid rejected, 14 ordered steps |

## 4. Edge cases covered

- **Numeric boundaries:** 0 and 6 rejected for a 1–5 field; 2.5 rejected as non-integer.
- **Empty values:** value-level validators allow empty (required-ness enforced separately) — verified.
- **Wrong-prefix IDs:** `TSK-…` rejected when an `IDE` id is required; unknown prefix `ZZZ` rejected; lowercase/malformed rejected.
- **Reversed schedule:** `Scheduled_End ≤ Scheduled_Start` rejected.
- **Self-referential source:** `Source_Content_ID == Content_ID` rejected (record-level rule).
- **Secret leakage:** nested and header-cased secret keys (`api_key`, `Authorization`, nested `token`) redacted; non-secret siblings preserved.
- **Invalid timezone:** unresolvable zone rejected without throwing to the caller.
- **Invalid record on write:** repository `create` throws `RECORD_VALIDATION_FAILED` (REP-005) — no partial row written.
- **ID counter floor:** `ensureAtLeast` never lowers an existing counter (ID-005) — protects against reuse after import.
- **Idempotent seed:** re-running init does not duplicate CONFIG/SETUP/CHANGELOG/workflow rows (design; confirmed by seed-if-empty guards, to be re-verified in-GAS).

## 5. In-GAS run output

_Paste the `CreatorOS ▸ Run Tests` summary here after execution._

```
(pending — see KNOWN_ISSUES I-01)
```

## 6. Acceptance-exit status (docs 21 §14)

| Criterion | Target | Current |
|---|---|---|
| Critical tests pass | 100% | pure 100%; in-GAS pending |
| No critical defect | required | met (0) |
| No API key exposure | required | met (design + sanitize verified) |
| No duplicate calendar events | required | N/A this milestone (calendar in M3) |

Release candidate status for M1: **pending in-GAS confirmation of the 19 Spreadsheet-bound cases**, then green.
