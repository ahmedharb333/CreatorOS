# Screenshots — capture checklist

**No screenshots are included in this package, and none are fabricated.**

Runtime screenshots require the bound Apps Script project to be running — which cannot happen in the build
environment (there is no Google session or Spreadsheet API here; see `docs/KNOWN_ISSUES.md` I-01). Per the
project's own QA rule ("no milestone is accepted based only on screenshots"), the milestone evidence is the
**executed pure-logic suite (34/34)** and **static analysis (25/25)** in `docs/TEST_RESULTS.md` and
`tests/pure_test_output.txt` — not images.

## Capture these after `clasp push` + Initialize / Repair (then drop the PNGs in this folder)

Suggested filenames:

1. `01-menu.png` — the **CreatorOS** custom menu open in the Sheet.
2. `02-home.png` — the HOME tab (title, tagline, version).
3. `03-all-tabs.png` — the tab strip showing all 16 sheets in order.
4. `04-ideas-schema.png` — IDEAS headers + data validation dropdown (e.g. Strategic_Goal showing 7 values).
5. `05-workflows.png` — WORKFLOWS populated with the 8 default workflows (74 steps).
6. `06-config-named-ranges.png` — CONFIG values + the Named Ranges panel (`CFG_*` resolved).
7. `07-verify-schema.png` — the **"Schema OK"** alert from Verify Schema.
8. `08-run-tests.png` — the **Run Tests** summary alert (all suites green).
9. `09-priority-formula.png` — an IDEAS row where Priority_Score computes (e.g. 5/4/2 → 3.3).
10. `10-protection-warning.png` — the warning prompt when editing a protected ID/formula cell.

Once captured, reference them from `docs/TEST_RESULTS.md §5` alongside the pasted in-GAS run output.
